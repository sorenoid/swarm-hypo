java -jar lib/swarm.jar gov.usgs.swarm.Swarm $*
